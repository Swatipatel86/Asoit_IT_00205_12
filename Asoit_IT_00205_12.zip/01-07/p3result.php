<?php
$firstname = $_POST['name'];

$Gender = $_POST['gen'];
$DOB = $_POST['no'];
$Language = $_POST['language'];
$Email = $_POST['email'];
$Mobile = $_POST['no1'];
$Username = $_POST['uname'];
$password = $_POST['password'];
$Confirmpassword = $_POST['cpassword'];

$data = "First name:$firstname <br/> Gender:$Gender <br/> DOB:$DOB <br/> Language:$Language <br/>
Email:$Email <br/> Mobile:$Mobile<br/> Username:$Username <br/> Password:$password <br/> Confirm password:$Confirmpassword <br/>";
echo $data;
exit;
?>