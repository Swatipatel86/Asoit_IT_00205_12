<html>
<!DOCTYPE html>
<head>
    <title>Registration Form</title>
    <style>
        .container{
            width:40%;
            font-size:20px;
            padding:7px;
            margin:5px;
            border:1px solid black;
            height:700px;
            
        }
    </style>
</head>
<body>
    <div>
        <?php
        if(isset($_post['container'])){
            echo "Enter submitted";
        }
        ?>
    </div>

    <div class="container">
    <h2>Registration Form</h2>
    <form action="p3result.php" method="POST">
        First Name:<input type="text" name="name">
        <br>
        <br>
        
        Gender:
        <label for="gen">
        <input type="radio" name="gen">Male<input type="radio" name="gen">Female
        </label>
        <br>
        <br>
        DOB:
        <input type="date" name="no">
        <br>
        <br>
        
        <lable for="Language">Language</lable>
        <select name="language" id="Language">
        
        <option value="Gujarati">Gujarati</option>
        <option value="English">English</option>
        <option value="Hindi">Hindi</option>
        </select>
        <br>
        <br>
        Email:
        <input type="email" name="email">
        <br>
        <br>

        Mobile:
        <input type="number" name="no1">
        <br>
        <br>
        Username:
        <input tyepe="text" name="uname">
        <br>
        <br>
        password:
        <input type="password" name="password">
        <br>
        <br>
        confirm password:
        <input type="cpassword" name="cpassword">
        <br>
        <br>
        

        <a href="http://localhost/swati/p3result.php">

        <input type="submit" name="submit" value="submit">
        
    
    </form>
</div>
</body>
</html>